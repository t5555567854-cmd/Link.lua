# Chess Trainer (Android, Kotlin)
Screen capture -> board/pieces recognition -> Stockfish -> arrow overlay. For games vs bots / training.

## Build
1. Open the folder in Android Studio (creates the Gradle wrapper), or `gradle assembleDebug`.
2. Put an Android arm64 Stockfish executable at `app/src/main/jniLibs/arm64-v8a/libstockfish.so` (renamed binary).
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Use
Overlay permission -> Start -> open a bot game at the START position -> notification "Нажми, чтобы обвести доску" -> drag rectangle -> OK.
Set the "I play white" switch BEFORE outlining. If the board is lost, a notification asks to outline again.

## Limits
Templates are kept in memory (re-outline after restart). Recognition needs a constant piece set/theme.
En passant is not tracked; castling rights are guessed from king/rook home squares. Promotion pieces are matched as normal pieces.
