package com.mc1h.chesshelper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class ArrowView(c: Context) : View(c) {
    /** x1,y1,x2,y2 in screen pixels, or null. */
    var arrow: FloatArray? = null
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC2E9BFF.toInt(); strokeWidth = 14f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC2E9BFF.toInt(); style = Paint.Style.FILL }

    override fun onDraw(cv: Canvas) {
        val a = arrow ?: return
        val ang = atan2(a[3] - a[1], a[2] - a[0]); val h = 46f
        val bx = a[2] - cos(ang) * h * 0.8f; val by = a[3] - sin(ang) * h * 0.8f
        cv.drawLine(a[0], a[1], bx, by, line)
        cv.drawCircle(a[0], a[1], 18f, fill)
        val p = Path()
        p.moveTo(a[2], a[3])
        p.lineTo(a[2] - cos(ang - 0.45f) * h, a[3] - sin(ang - 0.45f) * h)
        p.lineTo(a[2] - cos(ang + 0.45f) * h, a[3] - sin(ang + 0.45f) * h)
        p.close(); cv.drawPath(p, fill)
    }
}
