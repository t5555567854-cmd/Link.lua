package com.mc1h.chesshelper

/** Board arrays are indexed rank*8+file (a1=0, h1=7, a8=56). */
object Fen {
    const val START = "RNBQKBNRPPPPPPPP................................pppppppprnbqkbnr"

    fun make(b: CharArray, side: Char): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var e = 0
            for (f in 0..7) {
                val c = b[r * 8 + f]
                if (c == '.') e++ else { if (e > 0) { sb.append(e); e = 0 }; sb.append(c) }
            }
            if (e > 0) sb.append(e)
            if (r > 0) sb.append('/')
        }
        sb.append(' ').append(side).append(' ')
        val cs = StringBuilder()
        if (b[4] == 'K' && b[7] == 'R') cs.append('K')
        if (b[4] == 'K' && b[0] == 'R') cs.append('Q')
        if (b[60] == 'k' && b[63] == 'r') cs.append('k')
        if (b[60] == 'k' && b[56] == 'r') cs.append('q')
        sb.append(if (cs.isEmpty()) "-" else cs).append(" - 0 1")
        return sb.toString()
    }
}
