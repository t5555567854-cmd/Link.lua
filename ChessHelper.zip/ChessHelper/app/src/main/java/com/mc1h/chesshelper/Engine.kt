package com.mc1h.chesshelper

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/** UCI engine launched from jniLibs/arm64-v8a/libstockfish.so (an Android executable you supply). */
class Engine(private val ctx: Context) {
    private var proc: Process? = null
    private var rd: BufferedReader? = null
    private var wr: OutputStreamWriter? = null

    fun start(): Boolean {
        val f = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!f.exists()) return false
        return try {
            val p = ProcessBuilder(f.path).redirectErrorStream(true).start()
            proc = p; rd = BufferedReader(InputStreamReader(p.inputStream)); wr = OutputStreamWriter(p.outputStream)
            send("uci"); waitFor("uciok"); send("isready"); waitFor("readyok"); true
        } catch (e: Exception) { false }
    }

    private fun send(s: String) { wr?.write(s + "\n"); wr?.flush() }
    private fun waitFor(tok: String) { while (true) { val l = rd?.readLine() ?: return; if (l.startsWith(tok)) return } }

    fun best(fen: String, ms: Int): String? {
        send("position fen $fen"); send("go movetime $ms")
        while (true) {
            val l = rd?.readLine() ?: return null
            if (l.startsWith("bestmove")) { val m = l.split(" ").getOrNull(1); return if (m == null || m == "(none)") null else m }
        }
    }

    fun stop() { try { send("quit") } catch (_: Exception) {}; proc?.destroy() }
}
