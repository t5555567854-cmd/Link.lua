package com.mc1h.chesshelper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min

/** Transparent overlay: drag a rectangle around the board, tap OK. Board must show the START position. */
class CalibrateActivity : Activity() {
    private var x0 = 0f; private var y0 = 0f; private var x1 = 0f; private var y1 = 0f; private var has = false

    inner class RectView(c: Context) : View(c) {
        private val p = Paint().apply { color = 0xFFFF3B30.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f }
        private val loc = IntArray(2)
        override fun onDraw(cv: Canvas) {
            if (!has) return
            getLocationOnScreen(loc)
            cv.drawRect(minOf(x0, x1) - loc[0], minOf(y0, y1) - loc[1], maxOf(x0, x1) - loc[0], maxOf(y0, y1) - loc[1], p)
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; x1 = x0; y1 = y0; has = true }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> { x1 = e.rawX; y1 = e.rawY }
            }
            invalidate(); return true
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.setBackgroundColor(0x33000000)
        root.addView(RectView(this))
        root.addView(TextView(this).apply {
            text = "Поставь стартовую позицию и обведи доску пальцем"
            setTextColor(-1); setBackgroundColor(0xAA000000.toInt()); setPadding(24, 24, 24, 24)
        }, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        root.addView(Button(this).apply {
            text = "OK"
            setOnClickListener {
                if (!has || abs(x1 - x0) < 200) return@setOnClickListener
                val side = min(abs(x1 - x0), abs(y1 - y0)).toInt()
                getSharedPreferences("cfg", MODE_PRIVATE).edit()
                    .putInt("l", minOf(x0, x1).toInt()).putInt("t", minOf(y0, y1).toInt()).putInt("side", side).apply()
                startService(Intent(this@CalibrateActivity, ProjectionService::class.java).setAction(ProjectionService.ACTION_LEARN))
                finish()
            }
        }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
    }
}
