package com.mc1h.chesshelper

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Reads a board screenshot (square bitmap, only the board). Piece = pixels that differ from the
 * square's own background; the silhouette is matched against templates learned from the start position.
 */
object BoardReader {
    const val N = 20          // samples per square side
    const val OCC = 0.12f     // min fraction of "piece" pixels to call a square occupied
    const val DIFF = 45f      // RGB distance from background that counts as piece pixel
    const val MAXD = 0.30f    // max silhouette mismatch to accept a template match

    class Cell(val mask: BooleanArray, val frac: Float, val lum: Float)

    /** Result indexed rank*8+file. */
    fun cells(bmp: Bitmap, white: Boolean): Array<Cell> {
        val s = bmp.width / 8f
        val out = arrayOfNulls<Cell>(64)
        for (row in 0..7) for (col in 0..7) {
            val x0 = col * s; val y0 = row * s
            var br = 0f; var bg = 0f; var bb = 0f; var n = 0
            for (cx in intArrayOf(2, (s - 5).toInt())) for (cy in intArrayOf(2, (s - 5).toInt()))
                for (dx in 0..2) for (dy in 0..2) {
                    val p = bmp.getPixel((x0 + cx + dx).toInt(), (y0 + cy + dy).toInt())
                    br += (p shr 16) and 255; bg += (p shr 8) and 255; bb += p and 255; n++
                }
            br /= n; bg /= n; bb /= n
            val mask = BooleanArray(N * N); var cnt = 0
            for (gy in 0 until N) for (gx in 0 until N) {
                val x = x0 + s * (0.08f + 0.84f * (gx + 0.5f) / N)
                val y = y0 + s * (0.08f + 0.84f * (gy + 0.5f) / N)
                val p = bmp.getPixel(x.toInt(), y.toInt())
                val dr = ((p shr 16) and 255) - br
                val dg = ((p shr 8) and 255) - bg
                val db = (p and 255) - bb
                if (sqrt(dr * dr + dg * dg + db * db) > DIFF) { mask[gy * N + gx] = true; cnt++ }
            }
            val (f, r) = if (white) col to 7 - row else 7 - col to row
            out[r * 8 + f] = Cell(mask, cnt.toFloat() / (N * N), 0.299f * br + 0.587f * bg + 0.114f * bb)
        }
        return out.map { it!! }.toTypedArray()
    }

    /** Light/dark background pattern must match a chessboard; otherwise the board is "lost". */
    private fun gridOk(c: Array<Cell>): Boolean {
        var ls = 0f; var ln = 0; var ds = 0f; var dn = 0
        for (i in 0..63) if ((i % 8 + i / 8) % 2 == 1) { ls += c[i].lum; ln++ } else { ds += c[i].lum; dn++ }
        val lm = ls / ln; val dm = ds / dn
        if (lm - dm < 12) return false
        var ok = 0
        for (i in 0..63) { val m = if ((i % 8 + i / 8) % 2 == 1) lm else dm; if (abs(c[i].lum - m) < 25) ok++ }
        return ok >= 54
    }

    /** Learn 12 silhouettes from the standard start position. Null if the screen is not a start position. */
    fun learn(bmp: Bitmap, white: Boolean): Map<Char, BooleanArray>? {
        val c = cells(bmp, white)
        if (!gridOk(c)) return null
        val votes = HashMap<Char, IntArray>(); val cnt = HashMap<Char, Int>()
        for (i in 0..63) {
            val exp = Fen.START[i]
            if ((exp == '.') != (c[i].frac < OCC)) return null
            if (exp == '.') continue
            val v = votes.getOrPut(exp) { IntArray(N * N) }
            for (k in v.indices) if (c[i].mask[k]) v[k]++
            cnt[exp] = (cnt[exp] ?: 0) + 1
        }
        return votes.mapValues { (ch, v) -> BooleanArray(N * N) { v[it] * 2 > cnt[ch]!! } }
    }

    fun read(bmp: Bitmap, white: Boolean, t: Map<Char, BooleanArray>): CharArray? {
        val c = cells(bmp, white)
        if (!gridOk(c)) return null
        val out = CharArray(64) { '.' }
        for (i in 0..63) {
            if (c[i].frac < OCC) continue
            var best = 1f; var bc = '.'
            for ((ch, m) in t) {
                var d = 0
                for (k in m.indices) if (m[k] != c[i].mask[k]) d++
                val dd = d.toFloat() / m.size
                if (dd < best) { best = dd; bc = ch }
            }
            if (best > MAXD) return null
            out[i] = bc
        }
        return out
    }
}
