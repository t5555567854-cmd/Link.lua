package com.mc1h.chesshelper

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat

class ProjectionService : Service() {
    companion object { const val ACTION_START = "start"; const val ACTION_LEARN = "learn"; const val ACTION_STOP = "stop" }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var work: Handler
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var overlay: ArrowView? = null
    private var engine: Engine? = null
    @Volatile private var lastFrame: Bitmap? = null
    @Volatile private var templates: Map<Char, BooleanArray>? = null
    private var pending: CharArray? = null; private var stable = 0
    private var acted: CharArray? = null
    private var lost = 0
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    private fun calibIntent() = PendingIntent.getActivity(this, 0,
        Intent(this, CalibrateActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)

    private fun channels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("run", "Работа", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "Доска потеряна", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            ACTION_START -> if (!running) startCapture(i)
            ACTION_LEARN -> main.postDelayed({ learn() }, 700)
            ACTION_STOP -> { stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(i: Intent) {
        channels()
        val n = NotificationCompat.Builder(this, "run").setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Chess Trainer работает").setContentText("Нажми, чтобы обвести доску")
            .setContentIntent(calibIntent()).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = IntentCompat.getParcelableExtra(i, "data", Intent::class.java) ?: return stopSelf()
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(i.getIntExtra("code", Activity.RESULT_CANCELED), data)
        mp.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        projection = mp
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        work = Handler(HandlerThread("work").also { it.start() }.looper)
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val pl = img.planes[0]
                val bmp = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(pl.buffer); lastFrame = bmp
            } finally { img.close() }
        }, work)
        reader = r
        vd = mp.createVirtualDisplay("cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        val ov = ArrowView(this)
        wm.addView(ov, WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })
        overlay = ov
        running = true
        work.post {
            val e = Engine(this)
            if (e.start()) engine = e
            else main.post { Toast.makeText(this, "Не найден libstockfish.so в jniLibs/arm64-v8a", Toast.LENGTH_LONG).show() }
        }
        main.postDelayed(::tick, 800)
    }

    private fun crop(frame: Bitmap): Bitmap? {
        val p = prefs(); val s = p.getInt("side", 0); val l = p.getInt("l", 0); val t = p.getInt("t", 0)
        if (s < 200 || l < 0 || t < 0 || l + s > frame.width || t + s > frame.height) return null
        return Bitmap.createBitmap(frame, l, t, s, s)
    }

    private fun learn() {
        val f = lastFrame ?: return Toast.makeText(this, "Нет кадра", Toast.LENGTH_SHORT).show()
        val white = prefs().getBoolean("white", true)
        work.post {
            val b = crop(f)
            val t = if (b != null) BoardReader.learn(b, white) else null
            templates = t; pending = null; acted = null; stable = 0; lost = 0
            main.post {
                overlay?.arrow = null; overlay?.invalidate()
                Toast.makeText(this, if (t != null) "Доска и фигуры распознаны" else
                    "Не стартовая позиция или неверная рамка/цвет. Обведи заново", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Hide our arrow so it does not pollute the capture, then analyze the frame. */
    private fun tick() {
        if (!running) return
        val ov = overlay ?: return
        if (templates == null) { main.postDelayed(::tick, 800); return }
        ov.visibility = View.INVISIBLE
        main.postDelayed({
            val fr = lastFrame
            ov.visibility = View.VISIBLE
            if (fr != null) work.post { analyze(fr) }
            main.postDelayed(::tick, 700)
        }, 160)
    }

    private fun analyze(frame: Bitmap) {
        val t = templates ?: return
        val white = prefs().getBoolean("white", true)
        val bmp = crop(frame)
        val b = if (bmp != null) BoardReader.read(bmp, white, t) else null
        if (b == null) {
            lost++
            if (lost == 4) { main.post { overlay?.arrow = null; overlay?.invalidate() }; notifyLost() }
            return
        }
        lost = 0
        if (pending != null && b.contentEquals(pending)) stable++ else { pending = b; stable = 1 }
        if (stable < 2 || (acted != null && b.contentEquals(acted))) return
        val prev = acted; acted = b
        val user = if (white) 'w' else 'b'
        var mover: Char? = null
        if (prev != null) for (i in 0..63) if (b[i] != '.' && b[i] != prev[i]) { mover = if (b[i].isUpperCase()) 'w' else 'b'; break }
        val side = when {
            prev == null && String(b) == Fen.START -> 'w'
            mover == null -> user
            mover == 'w' -> 'b' else -> 'w'
        }
        if (side != user) { main.post { overlay?.arrow = null; overlay?.invalidate() }; return }
        val mv = engine?.best(Fen.make(b, side), 700) ?: return
        val p = prefs(); val s = p.getInt("side", 0) / 8f; val l = p.getInt("l", 0); val tp = p.getInt("t", 0)
        fun pt(file: Int, rank: Int): Pair<Float, Float> {
            val col = if (white) file else 7 - file; val row = if (white) 7 - rank else rank
            return Pair(l + (col + 0.5f) * s, tp + (row + 0.5f) * s)
        }
        val a = pt(mv[0] - 'a', mv[1] - '1'); val z = pt(mv[2] - 'a', mv[3] - '1')
        main.post { overlay?.arrow = floatArrayOf(a.first, a.second, z.first, z.second); overlay?.invalidate() }
    }

    private fun notifyLost() {
        val n = NotificationCompat.Builder(this, "alert").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Доска не видна").setContentText("Нажми и обведи доску заново")
            .setContentIntent(calibIntent()).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    override fun onDestroy() {
        running = false
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        vd?.release(); reader?.close(); projection?.stop(); engine?.stop()
        super.onDestroy()
    }
}
