package com.mc1h.chesshelper

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        ll.addView(TextView(this).apply {
            text = "Тренажёр: подсказки для партий против бота.\n1) Разреши оверлей. 2) Старт. 3) Открой партию с ботом (стартовая позиция), потяни шторку и нажми «Обвести доску»."
        })
        ll.addView(Switch(this).apply {
            text = "Я играю белыми"; isChecked = prefs.getBoolean("white", true)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("white", v).apply() }
        })
        ll.addView(Button(this).apply {
            text = "1. Разрешить оверлей"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        })
        ll.addView(Button(this).apply {
            text = "2. Старт"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) { Toast.makeText(this@MainActivity, "Нет разрешения на оверлей", Toast.LENGTH_LONG).show(); return@setOnClickListener }
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), 100)
            }
        })
        ll.addView(Button(this).apply {
            text = "Стоп"
            setOnClickListener { startService(Intent(this@MainActivity, ProjectionService::class.java).setAction(ProjectionService.ACTION_STOP)) }
        })
        setContentView(ll)
    }

    @Deprecated("simple flow")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 100 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, ProjectionService::class.java)
                .setAction(ProjectionService.ACTION_START).putExtra("code", res).putExtra("data", data))
        }
    }
}
